package ua.nickols.afkzone;

import org.bukkit.plugin.java.JavaPlugin;

public class AFKZonePlugin extends JavaPlugin {

    private AFKManager afkManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.afkManager = new AFKManager(this);
        this.afkManager.loadReturnLocations();
        this.afkManager.startTask();

        getServer().getPluginManager().registerEvents(new ActivityListener(this, afkManager), this);

        AFKCommand commandExecutor = new AFKCommand(this, afkManager);
        if (getCommand("afkzone") != null) {
            getCommand("afkzone").setExecutor(commandExecutor);
            getCommand("afkzone").setTabCompleter(commandExecutor);
        }

        getLogger().info("AFKZone увімкнено!");
    }

    @Override
    public void onDisable() {
        if (afkManager != null) {
            afkManager.stopTask();
            afkManager.saveReturnLocations();
        }
        getLogger().info("AFKZone вимкнено!");
    }

    public AFKManager getAfkManager() {
        return afkManager;
    }
}
