package ua.nickols.afkzone;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AFKCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = List.of("setspawn", "setzone", "spawn", "afk", "send", "return", "reload", "status");
    private final AFKZonePlugin plugin;
    private final AFKManager afkManager;


    public AFKCommand(AFKZonePlugin plugin, AFKManager afkManager) {
        this.plugin = plugin;
        this.afkManager = afkManager;
    }


    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("afkzone.admin")) {
            sender.sendMessage(msg("no-permission", "&cНедостатньо прав."));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(AFKManager.color("&6AFKZone &7Команди: &e/afkzone setspawn&7, &e/afkzone spawn&7, &e/afkzone afk <гравець>&7, &e/afkzone send <гравець>&7, &e/afkzone return <гравець>&7, &e/afkzone reload&7, &e/afkzone status"));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "setspawn", "setzone" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage(AFKManager.color("&cЦю команду може виконати лише гравець.")); return true; }
                afkManager.setAFKZoneLocation(player.getLocation());
                player.sendMessage(msg("zone-set", "&aТочку AFK-зони збережено!"));
            }
            case "spawn" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage(AFKManager.color("&cЦю команду може виконати лише гравець.")); return true; }
                if (afkManager.getAFKZoneLocation() == null) sender.sendMessage(msg("zone-not-set", "&cAFK-зону ще не встановлено. Використайте /afkzone setspawn."));
                else if (!afkManager.teleportToAFKZone(player)) sender.sendMessage(AFKManager.color("&cТелепортація не вдалася."));
                else player.sendMessage(msg("teleported-to-zone", "&aВас телепортовано в AFK-зону."));
            }
            case "afk", "send" -> {
                if (args.length < 2) { sender.sendMessage(AFKManager.color("&cВикористання: /afkzone " + sub + " <гравець>")); return true; }
                Player target = plugin.getServer().getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(AFKManager.color("&cГравця не знайдено або він офлайн.")); return true; }
                AFKManager.SendResult result = afkManager.sendToAFKZone(target);
                switch (result) {
                    case SUCCESS -> sender.sendMessage(AFKManager.color("&aГравця &e" + target.getName() + " &aвідправлено в AFK-зону."));
                    case ALREADY_AFK -> sender.sendMessage(AFKManager.color("&eГравець &6" + target.getName() + " &eвже перебуває в AFK-зоні."));
                    case ZONE_NOT_SET -> sender.sendMessage(msg("zone-not-set", "&cAFK-зону ще не встановлено. Використайте /afkzone setspawn."));
                    case TELEPORT_FAILED -> sender.sendMessage(AFKManager.color("&cНе вдалося телепортувати гравця &e" + target.getName() + "&c."));
                }
            }
            case "return" -> {
                if (args.length < 2) { sender.sendMessage(AFKManager.color("&cВикористання: /afkzone return <гравець>")); return true; }
                Player target = plugin.getServer().getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(AFKManager.color("&cГравця не знайдено або він офлайн.")); return true; }
                if (!afkManager.returnPlayerManually(target)) sender.sendMessage(AFKManager.color("&cГравець не в AFK або повернення не вдалося."));
                else sender.sendMessage(AFKManager.color("&aГравця &e" + target.getName() + " &aповернуто."));
            }
            case "reload" -> {
                plugin.reloadConfig();
                afkManager.startTask();
                sender.sendMessage(msg("reloaded", "&aКонфігурацію перезавантажено!"));
            }
            case "status" -> {
                Location zone = afkManager.getAFKZoneLocation();
                String zoneText = zone == null || zone.getWorld() == null ? "не налаштовано" : String.format(Locale.US, "%s (%.1f, %.1f, %.1f)", zone.getWorld().getName(), zone.getX(), zone.getY(), zone.getZ());
                sender.sendMessage(AFKManager.color("&6AFKZone &7— авто-AFK: " + (afkManager.isAutoAfkEnabled() ? "&aувімкнено" : "&cвимкнено") +
                        "&7, задача: " + (afkManager.isTaskRunning() ? "&aпрацює" : "&cне запущена") +
                        "&7, таймер: &e" + plugin.getConfig().getLong("afk-timeout-seconds", 180) + "с" +
                        "&7, автоповернення: " + (plugin.getConfig().getBoolean("auto-return-on-activity", true) ? "&aтак" : "&cні") +
                        "&7, зона: &e" + zoneText + "&7, AFK-гравців: &e" + afkManager.getActiveAfkCount() + "&7, збережених точок: &e" + afkManager.getSavedLocations().size()));
            }
            default -> sender.sendMessage(AFKManager.color("&cКоманда не знайдена. Використовуйте /afkzone"));
        }
        return true;
    }


    private String msg(String key, String fallback) { return AFKManager.color(plugin.getConfig().getString("messages." + key, fallback)); }


    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("afkzone.admin")) return List.of();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<>();
            for (String sub : SUBCOMMANDS) if (sub.startsWith(prefix)) matches.add(sub);
            return matches;
        }
        if (args.length == 2 && List.of("afk", "send", "return").contains(args[0].toLowerCase(Locale.ROOT))) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> names = new ArrayList<>();
            for (Player p : plugin.getServer().getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) names.add(p.getName());
            return names;
        }
        return List.of();
    }
}
