package ua.nickols.afkzone;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class AFKManager {
    public enum SendResult { SUCCESS, ALREADY_AFK, ZONE_NOT_SET, TELEPORT_FAILED }


    private final AFKZonePlugin plugin;
    private final Map<UUID, Long> lastActivity = new ConcurrentHashMap<>();
    private final Map<UUID, Location> savedLocations = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> afkPlayers = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> internalTeleports = new ConcurrentHashMap<>();

    private final File dataFile;
    private FileConfiguration dataConfig;
    private BukkitTask task;


    public AFKManager(AFKZonePlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "returns.yml");
    }


    public void startTask() {
        stopTask();
        if (!plugin.getConfig().getBoolean("auto-afk-enabled", true)) return;
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long timeoutMillis = Math.max(1L, plugin.getConfig().getLong("afk-timeout-seconds", 180)) * 1000L;
            long now = System.currentTimeMillis();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.hasPermission("afkzone.bypass")) continue;
                UUID uuid = player.getUniqueId();
                long last = lastActivity.computeIfAbsent(uuid, k -> now);
                if (!isAFK(uuid) && (now - last) >= timeoutMillis) sendToAFKZone(player);
            }
        }, 20L, 20L);
    }


    public void stopTask() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }


    public boolean isTaskRunning() { return task != null && !task.isCancelled(); }
    public boolean isAutoAfkEnabled() { return plugin.getConfig().getBoolean("auto-afk-enabled", true); }


    public void recordActivity(Player player) {
        UUID uuid = player.getUniqueId();
        lastActivity.put(uuid, System.currentTimeMillis());
        if (isAFK(uuid) && plugin.getConfig().getBoolean("auto-return-on-activity", true)) returnFromAFK(player, false);
    }


    public void handleJoin(Player player) {
        UUID uuid = player.getUniqueId();
        lastActivity.put(uuid, System.currentTimeMillis());
        // A persisted return location indicates the player was AFK when the server stopped or they disconnected.
        if (savedLocations.containsKey(uuid)) afkPlayers.put(uuid, true);
    }


    public void handleQuit(Player player) {
        UUID uuid = player.getUniqueId();
        lastActivity.remove(uuid);
        internalTeleports.remove(uuid);
        if (!isAFK(uuid)) {
            savedLocations.remove(uuid);
            removeSavedPlayerReturnLocation(uuid);
        } else {
            saveReturnLocations();
        }
    }


    public boolean isAFK(UUID uuid) { return afkPlayers.getOrDefault(uuid, false); }
    public boolean isInternalTeleport(UUID uuid) { return internalTeleports.remove(uuid) != null; }

    public int getActiveAfkCount() {
        int count = 0;
        for (Boolean state : afkPlayers.values()) if (Boolean.TRUE.equals(state)) count++;
        return count;
    }


    public boolean teleportToAFKZone(Player player) {
        Location zone = getAFKZoneLocation();
        return zone != null && zone.getWorld() != null && safeTeleport(player, zone);
    }


    public SendResult sendToAFKZone(Player player) {
        if (isAFK(player.getUniqueId())) return SendResult.ALREADY_AFK;
        Location zone = getAFKZoneLocation();
        if (zone == null || zone.getWorld() == null) {
            player.sendMessage(color(plugin.getConfig().getString("messages.zone-not-set", "&cAFK-зону не налаштовано!")));
            lastActivity.put(player.getUniqueId(), System.currentTimeMillis());
            return SendResult.ZONE_NOT_SET;
        }

        UUID uuid = player.getUniqueId();
        Location previous = player.getLocation().clone();
        savedLocations.put(uuid, previous);
        afkPlayers.put(uuid, true);
        savePlayerReturnLocation(uuid, previous);

        boolean success = safeTeleport(player, zone);
        if (!success) {
            afkPlayers.remove(uuid);
            savedLocations.remove(uuid);
            removeSavedPlayerReturnLocation(uuid);
            lastActivity.put(uuid, System.currentTimeMillis());
            return SendResult.TELEPORT_FAILED;
        }
        player.sendMessage(color(plugin.getConfig().getString("messages.entered-afk", "&eВи переміщені в AFK-зону.")));
        return SendResult.SUCCESS;
    }


    public void returnFromAFK(Player player) { returnFromAFK(player, false); }


    public boolean returnPlayerManually(Player player) { return returnFromAFK(player, true); }


    private boolean returnFromAFK(Player player, boolean forceReturn) {
        UUID uuid = player.getUniqueId();
        if (!isAFK(uuid)) return false;
        Location returnLoc = savedLocations.get(uuid);
        boolean shouldTeleport = forceReturn || plugin.getConfig().getBoolean("auto-return-on-activity", true);
        if (shouldTeleport && returnLoc != null && returnLoc.getWorld() != null) {
            if (!safeTeleport(player, returnLoc)) return false;
            player.sendMessage(color(plugin.getConfig().getString("messages.returned-from-afk", "&aВас повернуто назад.")));
        }
        afkPlayers.remove(uuid);
        savedLocations.remove(uuid);
        removeSavedPlayerReturnLocation(uuid);
        lastActivity.put(uuid, System.currentTimeMillis());
        return true;
    }


    private boolean safeTeleport(Player player, Location destination) {
        UUID uuid = player.getUniqueId();
        internalTeleports.put(uuid, true);
        boolean success;
        try {
            success = player.teleport(destination);
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Teleport failed for " + player.getName() + ": " + ex.getMessage());
            success = false;
        }
        if (!success) internalTeleports.remove(uuid);
        else Bukkit.getScheduler().runTask(plugin, () -> internalTeleports.remove(uuid));
        return success;
    }


    public void setAFKZoneLocation(Location loc) {
        FileConfiguration cfg = plugin.getConfig();
        cfg.set("afk-zone.world", loc.getWorld() != null ? loc.getWorld().getName() : "world");
        cfg.set("afk-zone.x", loc.getX());
        cfg.set("afk-zone.y", loc.getY());
        cfg.set("afk-zone.z", loc.getZ());
        cfg.set("afk-zone.yaw", loc.getYaw());
        cfg.set("afk-zone.pitch", loc.getPitch());
        plugin.saveConfig();
    }


    public Location getAFKZoneLocation() {
        FileConfiguration cfg = plugin.getConfig();
        String worldName = cfg.getString("afk-zone.world");
        if (worldName == null || worldName.isBlank()) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, cfg.getDouble("afk-zone.x"), cfg.getDouble("afk-zone.y"), cfg.getDouble("afk-zone.z"),
                (float) cfg.getDouble("afk-zone.yaw"), (float) cfg.getDouble("afk-zone.pitch"));
    }


    public void loadReturnLocations() {
        if (!dataFile.exists()) {
            try {
                File parent = dataFile.getParentFile();
                if (parent != null) parent.mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Не вдалося створити returns.yml: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection section = dataConfig.getConfigurationSection("players");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                Location loc = section.getLocation(key);
                if (loc != null && loc.getWorld() != null) savedLocations.put(uuid, loc);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Skipped invalid saved AFK UUID: " + key);
            }
        }
    }


    public void saveReturnLocations() {
        if (dataConfig == null) dataConfig = new YamlConfiguration();
        dataConfig.set("players", null);
        for (Map.Entry<UUID, Location> entry : savedLocations.entrySet()) dataConfig.set("players." + entry.getKey(), entry.getValue());
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не вдалося зберегти returns.yml: " + e.getMessage());
        }
    }


    private void savePlayerReturnLocation(UUID uuid, Location loc) {
        if (dataConfig == null) dataConfig = new YamlConfiguration();
        dataConfig.set("players." + uuid, loc);
        try { dataConfig.save(dataFile); }
        catch (IOException e) { plugin.getLogger().warning("Помилка збереження точки гравця: " + e.getMessage()); }
    }


    private void removeSavedPlayerReturnLocation(UUID uuid) {
        if (dataConfig == null) return;
        dataConfig.set("players." + uuid, null);
        try { dataConfig.save(dataFile); }
        catch (IOException e) { plugin.getLogger().warning("Помилка видалення точки гравця: " + e.getMessage()); }
    }


    public Map<UUID, Location> getSavedLocations() { return new HashMap<>(savedLocations); }

    public static String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }
}
