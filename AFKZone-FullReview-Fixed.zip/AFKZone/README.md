# AFKZone

Paper plugin targeting Minecraft 1.21.1 and Java 21.

## Commands (operator by default)
- `/afkzone setspawn` (alias `/afkzone setzone`) - set AFK-zone location at your current position.
- `/afkzone spawn` - teleport yourself to the AFK-zone.
- `/afkzone afk <player>` (alias `/afkzone send <player>`) - move an online player to the AFK-zone and save their return point.
- `/afkzone return <player>` - manually return an AFK player.
- `/afkzone reload` - reload config and restart AFK task.
- `/afkzone status` - show configuration and task status.

Permission: `afkzone.admin` (default operator). Exemption permission: `afkzone.bypass`.

Build with Gradle: `gradle clean build`. Output jar: `build/libs/AFKZone-1.0.0.jar`.
